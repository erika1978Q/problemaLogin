﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PeliculaAPI.Migrations
{
    public partial class cambios : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
