﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PeliculaAPI.DTOs
{
    public class EditarRolDTO
    {
        public string UsuarioId { get; set; }
        public string NombreRol { get; set; }
    }
}
