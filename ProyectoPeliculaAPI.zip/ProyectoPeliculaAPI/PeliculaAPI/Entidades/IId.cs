﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PeliculaAPI.Entidades
{
    public interface IId
    {
         int Id { get; set; }
    }
}
