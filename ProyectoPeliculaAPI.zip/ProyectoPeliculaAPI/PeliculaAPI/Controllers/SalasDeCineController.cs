﻿using AutoMapper;
using GeoAPI.Geometries;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
//using NetTopologySuite.Geometries;
using PeliculaAPI.DTOs;
using PeliculaAPI.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PeliculaAPI.Controllers
{
    [Route("api/SalasDeCine")]
    [ApiController]
    public class SalasDeCineController: CustomBaseController
    {
        private readonly ApplicationDbContext context2;
        private readonly IMapper mapper2;
        private readonly IGeometryFactory geometryFactory2;

        public SalasDeCineController(ApplicationDbContext context,
            IMapper mapper,
            IGeometryFactory geometryFactory)
            :base(context, mapper)
        {
            this.context2 = context;
            this.mapper2 = mapper;
            this.geometryFactory2 = geometryFactory;
        }

        [HttpGet]
        public async Task<ActionResult<List<SalaDeCineDTO>>> Get()
        {
            return await Get<SalaDeCine, SalaDeCineDTO>();
        }

        [HttpGet("{id:int}", Name = "obtenerSalaDeCine")]
        public async Task<ActionResult<SalaDeCineDTO>> Get(int id)
        {
            return await Get<SalaDeCine, SalaDeCineDTO>(id);
        }

        [HttpGet("Cercanos")]
        public async Task<ActionResult<List<SalaDeCineCercanoDTO>>> Cercanos(
            [FromQuery] SalaDeCineCercanoFiltroDTO filtro)
        {
            //---En  SQL -----------
            //Declare @MiUbicacion Geography = 'POINT(-69.938988 18.481208)'
            //select Id,
            //       Nombre,
            //       Ubicacion.ToString() as Ubicacion,
            //       Ubicacion.STDistance(@MiUbicacion) as Distancia
            // from[dbo].[SalasDeCine]
            // where Ubicacion.STDistance(@MiUbicacion) <= 3000 /**significa 3 kilometros**/
            // order by Ubicacion.STDistance(@MiUbicacion) asc 

            var ubicacionUsuario = geometryFactory2.CreatePoint(new Coordinate(filtro.Longitud, filtro.Latitud));

            var salasDeCine = await context2.SalasDeCine
                .OrderBy(x => x.Ubicacion.Distance(ubicacionUsuario))
                .Where(x => x.Ubicacion.IsWithinDistance(ubicacionUsuario, filtro.DistanciaEnKms * 1000))
                .Select(x => new SalaDeCineCercanoDTO
                {
                    Id = x.Id,
                    Nombre = x.Nombre,
                    Latitud = x.Ubicacion.Y,
                    Longitud = x.Ubicacion.X,
                    DistanciaEnMetros = Math.Round(x.Ubicacion.Distance(ubicacionUsuario))
                })
                .ToListAsync();

            return salasDeCine;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] SalaDeCineCreacionDTO salaDeCineCreacionDTO)
        {
            return await 
                Post<SalaDeCineCreacionDTO, SalaDeCine, SalaDeCineDTO>(salaDeCineCreacionDTO, "obtenerSalaDeCine");
        }

        [HttpPost("{id}/AgregarPelicula/{peliculaId}")]
        public async Task<ActionResult> AgregarPelicula(int id, int peliculaId)
        {
            var peliculaSalaDeCine = new PeliculasSalasDeCine() { PeliculaId = peliculaId, SalaDeCineId = id };
            context2.Add(peliculaSalaDeCine);
            await context2.SaveChangesAsync();
            return NoContent();
        }

        [HttpPut("{id:int}")]
        public async Task<ActionResult> Put(int id, [FromBody] SalaDeCineCreacionDTO salaDeCineCreacionDTO)
        {
            return await Put<SalaDeCineCreacionDTO, SalaDeCine>(id, salaDeCineCreacionDTO);
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult> Delete(int id)
        {
            return await Delete<SalaDeCine>(id);
        }
    }
}
