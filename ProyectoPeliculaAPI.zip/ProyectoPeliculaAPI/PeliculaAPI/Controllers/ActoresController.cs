﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PeliculaAPI.DTOs;
using PeliculaAPI.Entidades;
using PeliculaAPI.Servicios;
using PeliculaAPI.Helpers;

namespace PeliculaAPI.Controllers
{
    [Route("api/actores")]
    [ApiController]
    public class ActoresController : CustomBaseController
    {
        private readonly ApplicationDbContext context2;
        private readonly IMapper mapper2;
        private readonly IAlmacenadorArchivos almacenadorArchivo2;
        private readonly string contenedor = "actores";

        public ActoresController(ApplicationDbContext context,IMapper mapper,IAlmacenadorArchivos almacenadorArchivo) : base(context, mapper)
        {
            this.context2 = context;
            this.mapper2 = mapper;
            this.almacenadorArchivo2 = almacenadorArchivo;
        }
        //GET CON PAGINACION
        [HttpGet]
        public async Task<ActionResult<List<ActorDTO>>> Get([FromQuery] PaginacionDTO paginacionDTO)
        {
            //var queryable = context2.Actores.AsQueryable();
            //await HttpContext.InsertarParametrosPaginacion(queryable, paginacionDTO.CantidadRegistrosPorPagina);
            //var entidades = await queryable.Paginar(paginacionDTO).ToListAsync();
            //var dtos = mapper2.Map<List<ActorDTO>>(entidades);
            //return dtos;

            return await Get<Actor, ActorDTO>(paginacionDTO);
        }
        //[HttpGet]
        //public async Task<ActionResult<List<ActorDTO>>> Get()
        //{
        //    var entidades = await context2.Actores.ToListAsync();
        //    var dtos = mapper2.Map<List<ActorDTO>>(entidades);
        //    return dtos;
        //}

        // GET api/<controller>/5
        [HttpGet("{id:int}", Name = "obtenerActor")]
        public async Task<ActionResult<ActorDTO>> Get(int id)
        {
            //var entidad = await context2.Actores.FirstOrDefaultAsync(x => x.Id == id);
            //if (entidad == null)
            //{
            //    return NotFound();
            //}
            //var dto = mapper2.Map<ActorDTO>(entidad);
            //return dto;
            return await Get<Actor, ActorDTO>(id);
        }

        // POST api/<controller>
        [HttpPost]
        public async Task<ActionResult> Post([FromForm]ActorCreacionDTO actorCreacionDTO)
        {   //---------------SIN GRABAR FOTO-----------------------
            //Actor entidad = mapper2.Map<Actor>(actorCreacionDTO);
            //context2.Add(entidad);
            //await context2.SaveChangesAsync();
            //var actorDTO = mapper2.Map<ActorDTO>(entidad);
            //return new CreatedAtRouteResult("obtenerActor", new { id = actorDTO.Id }, actorDTO);
            //-----------------------------------------------------------------

            Actor entidad = mapper2.Map<Actor>(actorCreacionDTO);
            if (actorCreacionDTO.Foto!=null)
            {
                using (var memoryStream=new MemoryStream())
                {
                    await actorCreacionDTO.Foto.CopyToAsync(memoryStream);
                    var contenido = memoryStream.ToArray();
                    var extension = Path.GetExtension(actorCreacionDTO.Foto.FileName);
                    entidad.Foto = await almacenadorArchivo2.GuardarArchivo(contenido, extension, contenedor, actorCreacionDTO.Foto.ContentType);
                }
            }
            
            context2.Add(entidad);
            await context2.SaveChangesAsync();
            var actorDTO = mapper2.Map<ActorDTO>(entidad);
            return new CreatedAtRouteResult("obtenerActor", new { id = actorDTO.Id }, actorDTO);
        }

       

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromForm]ActorCreacionDTO actorCreacionDTO)
        {
            //-------------ES OBLIGATORIO MODIFICAR FOTO-------------
            //var entidad = mapper2.Map<Actor>(actorCreacionDTO);
            //entidad.Id = id;
            //context2.Entry(entidad).State = EntityState.Modified;
            //await context2.SaveChangesAsync();
            //return NoContent();
            //------------------------------------------------------

            var actorDB = await context2.Actores.FirstOrDefaultAsync(x => x.Id == id);
            if (actorDB==null)
            {
                return NotFound();
            }
            //Esto me permite grabar solo lo necesario que ha sufrido algun cambio
            actorDB = mapper2.Map(actorCreacionDTO, actorDB);

            if (actorCreacionDTO.Foto != null)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await actorCreacionDTO.Foto.CopyToAsync(memoryStream);
                    var contenido = memoryStream.ToArray();
                    var extension = Path.GetExtension(actorCreacionDTO.Foto.FileName);
                    actorDB.Foto = await almacenadorArchivo2.EditarArchivos(contenido, extension, contenedor, actorDB.Foto,actorCreacionDTO.Foto.ContentType);
                }
            }
            await context2.SaveChangesAsync();
            return NoContent();
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            //var existe = await context2.Actores.AnyAsync(x => x.Id == id);
            //if (!existe)
            //{
            //    return NotFound();
            //}
            //context2.Remove(new Actor() { Id = id });
            //await context2.SaveChangesAsync();
            //return NoContent();
            return await Delete<Actor>(id);
        }

        [HttpPatch("{id}")]
        //Se debe instalar sino se tiene microsoft.aspnetcore.jsonpatch
        public async Task<ActionResult> Patch(int id, [FromBody] JsonPatchDocument<ActorPatchDTO> patchDocument)
        {
            //if (patchDocument == null)
            //{
            //    return BadRequest();
            //}
            //var entidadDB = await context2.Actores.FirstOrDefaultAsync(x => x.Id == id);
            //if (entidadDB == null)
            //{
            //    return NotFound();
            //}
            //var entidadDTO = mapper2.Map<ActorPatchDTO>(entidadDB);
            //patchDocument.ApplyTo(entidadDTO, ModelState);
            //var esValido = TryValidateModel(entidadDTO);
            //if (!esValido)
            //{
            //    return BadRequest(ModelState);
            //}
            //mapper2.Map(entidadDTO, entidadDB);
            //await context2.SaveChangesAsync();

            //return NoContent();
            return await Patch<Actor, ActorPatchDTO>(id, patchDocument);
        }
    }
}